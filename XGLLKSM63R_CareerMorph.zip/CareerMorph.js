// Add animations on scroll
document.addEventListener('DOMContentLoaded', () => {
    const cards = document.querySelectorAll('.roadmap-card, .skill-card, .transition-card');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate__fadeInUp');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    cards.forEach(card => observer.observe(card));
});

function uploadFile(event) {
    const careerAssessments = [
        "Eightfold AI Career Hub – Uses AI to suggest job roles based on skills and experience",
        "Pymetrics Assessment – AI-driven neuroscience games analyze cognitive and emotional traits for career fit",
        "CareerExplorer AI Assessment – Uses machine learning to provide career matches based on skills, personality, and interests",
        "Skills Matcher (CareerOneStop) – Matches existing skills with potential careers",
        "GROW Model Self-Assessment – Helps set specific learning and career development goals",
        "Gap Analysis Test (Udemy, Coursera, LinkedIn Learning) – Identifies technical and soft skills to improve",
    ];
    const aiCareerInsights = [
        "Eightfold AI Career Hub",
        "Pymetrics Assessment",
        "CareerExplorer AI Assessment",
        "LinkedIn Skill Assessments",
        "Google Career Certificates AI Advisor",
        "Coursera Career Coach",
        "IBM Watson Career Coach",
        "Glassdoor Job Fit Insights",
        "O*NET AI Career Profiler",
        "HireVue AI Assessment",
        "Crystal Knows Personality AI",
        "Predictive Index Cognitive Assessment"
    ];
    const upskillCertifyAssessments = [
        "LinkedIn Skill Assessments",
        "Coursera Certification Tests",
        "Google Career Certificates",
        "AWS Certified Cloud Practitioner",
        "Microsoft Certified: Azure Fundamentals",
        "IBM Data Science Professional Certificate",
        "Udacity Nanodegree Assessments",
        "Harvard Online Course Certifications",
        "edX Professional Certificate Programs",
        "Skillshare Project-Based Assessments",
        "Pluralsight Skill IQ Tests",
        "HubSpot Content Marketing Certification"
    ];

    let car = document.getElementById("car");
    let ca = document.getElementById("ca");
    let c = document.getElementById("c");
    // Function to pick a random career assessment
    function getRandomAssessment() {
        const randomIndex = Math.floor(Math.random() * careerAssessments.length);
        car.textContent = careerAssessments[randomIndex];
        const randomIndexs = Math.floor(Math.random() * aiCareerInsights.length);
        ca.textContent = aiCareerInsights[randomIndexs];
        const randomInde = Math.floor(Math.random() * upskillCertifyAssessments.length);
        c.textContent = upskillCertifyAssessments[randomInde];

    }

    console.log(getRandomAssessment()); // Example usage
    let x = Math.ceil(Math.random() * 100);
    const file = event.target.files[0];
    if (file) {
        document.getElementById("uploadStatus").textContent = "✅ Uploaded: " + file.name;
        document.getElementById("profileStrength").textContent = x + "%";
        document.getElementById("progressBar").style.width = x + "%";

    }
}
document.addEventListener('DOMContentLoaded', function() {
    // Add entrance animations
    const cards = document.querySelectorAll('.step-card');

    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';

        setTimeout(() => {
            card.style.transition = 'all 0.5s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100 * (index + 1));
    });

    // Add hover animation for learn more buttons
    const learnMoreButtons = document.querySelectorAll('.learn-more');

    learnMoreButtons.forEach(button => {
        button.addEventListener('mouseenter', () => {
            const arrow = button.querySelector('.arrow-icon');
            arrow.style.transform = 'translateX(4px)';
        });

        button.addEventListener('mouseleave', () => {
            const arrow = button.querySelector('.arrow-icon');
            arrow.style.transform = 'translateX(0)';
        });
    });
});
document.addEventListener('DOMContentLoaded', function() {
    const track = document.querySelector('.reviews-track');
    const cards = document.querySelectorAll('.review-card');

    // Clone the reviews to ensure smooth scrolling
    cards.forEach(card => {
        const clone = card.cloneNode(true);
        track.appendChild(clone);
    });
});